/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fx10primeiros;

/**
 *
 * @author francisco.fraga
 */
public class Fx10primeiros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n = 14, x = 4, fx = 0;
       
       while (x < n){
       
           fx = 2*(x*x) + 3*x + 5;
           x++;
           System.out.print("\nValor de f(x): " + fx);
       }
        
       
       
       
        
    }
    
}
