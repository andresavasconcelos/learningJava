class Erro03 {
	
	public static void main (String[] args){

		//System.out.println("Voce digitou: ");
		System.out.println("Voce digitou: " + 1/0);
	}
}