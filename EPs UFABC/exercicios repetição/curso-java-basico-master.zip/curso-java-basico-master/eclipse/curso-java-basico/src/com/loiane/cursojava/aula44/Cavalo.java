package com.loiane.cursojava.aula44;

public class Cavalo extends Mamifero implements AnimalDomesticado {

	@Override
	public void amamentar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub

	}

	@Override
	public void levarVeterinario() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void alimentar() {
		// TODO Auto-generated method stub
		
	}

}
