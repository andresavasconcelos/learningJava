package com.loiane.cursojava.aula28;

import com.loiane.cursojava.aula15.labs.Exer10;
import com.loiane.cursojava.aula20.labs.Exer04;
import com.loiane.cursojava.aula20.labs.Exer05;
import com.loiane.cursojava.aula20.labs.Exer06;
import com.loiane.cursojava.aula27.Carro;

public class Pacotes {

	public static void main(String[] args) {
		
		Carro carro;
		Carro carro2;
		
		Exer06 exer06;
		Exer05 exer05;
		Exer04 exer04;
		
		Exer10 exer10;
	}

}
