package com.loiane.cursojava.aula44;

public interface Constantes {

	String URL_BLOG = "http://loiane.com";
	String CURSO_COMPLETO = "http://loiane.training";
	
}
