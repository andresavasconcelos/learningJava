package com.loiane.cursojava.aula44;

public interface AnimalDomesticado {

	public final int ANO = 2016;
	
	void levarVeterinario();
	void alimentar();
}
