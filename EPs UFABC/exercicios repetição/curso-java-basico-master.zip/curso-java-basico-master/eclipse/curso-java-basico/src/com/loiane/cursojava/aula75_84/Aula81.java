package com.loiane.cursojava.aula75_84;

public class Aula81 {

	public static void main(String[] args) {
		
		String teste = "Teste";
		
		String testeMinusc = teste.toLowerCase();
		String testeMaisc = teste.toUpperCase();

		System.out.println(testeMinusc);
		System.out.println(testeMaisc);
		
		//if (teste.toLowerCase().equals(teste.toLowerCase()))
	}

}
